<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/bootstrap/css/custom-button.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/font-awesome-4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/ionicons-2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/dist/css/AdminLTE.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/dist/css/skins/_all-skins.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/morris/morris.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/fapicker/dist/css/fontawesome-iconpicker.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/fontawesome/css/all.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/dist/css.css">
<link rel="icon" href="<?php echo base_url(); ?>assets/images/favicon.png" type="image/gif">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/app/css/print.css">
<link rel="stylesheet" href="<?php echo base_url()  ?>assets/plugins/datepicker/datepicker3.css">
<script src="<?php echo base_url() ?>assets/plugins/jQuery/jQuery-2.1.4.min.js"></script>



